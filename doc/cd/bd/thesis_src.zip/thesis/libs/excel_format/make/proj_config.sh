#!/bin/bash

######################################################################
#---------------------- PROJECT CONFIGURATIONS ----------------------#
######################################################################

# Full name of the project
PROJ_NAME=ExcelFormat

# Code name of the project
PROJ_CODE_NAME=excel_format