#!/bin/bash

######################################################################
#---------------------- PROJECT CONFIGURATIONS ----------------------#
######################################################################

# Full name of the project
PROJ_NAME=ClassifierQuality

# Code name of the project
PROJ_CODE_NAME=cquality