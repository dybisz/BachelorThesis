//
// Created by jakub on 1/6/16.
//

#ifndef BACHELOR_THESIS_PSO_OBJECT_TEST_H
#define BACHELOR_THESIS_PSO_OBJECT_TEST_H

#include <pso/pso_object.h>

using namespace pso;

/*
 * This class is used to test test the communication
 * between classes in the entire module.
 */
class PSOObjectTest : public PSOObject {
public:
    PSOObjectTest(){

    }

    virtual ~PSOObjectTest(){

    }
};


#endif //BACHELOR_THESIS_PSO_OBJECT_TEST_H
