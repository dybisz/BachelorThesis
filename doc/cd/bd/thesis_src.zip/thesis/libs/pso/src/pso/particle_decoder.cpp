//
// Created by jakub on 12/29/15.
//

#include <pso/particle_decoder.h>

//-----------------------------------------------------------//
//  CONSTRUCTOR
//-----------------------------------------------------------//

pso::ParticleDecoder::ParticleDecoder() {

}

pso::ParticleDecoder::~ParticleDecoder() {

}
