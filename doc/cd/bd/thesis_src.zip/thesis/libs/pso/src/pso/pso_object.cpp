//
// Created by jakub on 12/29/15.
//

#include <pso/pso_object.h>

using namespace pso;

//-----------------------------------------------------------//
//  CONSTRUCTORS
//-----------------------------------------------------------//

PSOObject::PSOObject() {

}

PSOObject::~PSOObject() {

}
