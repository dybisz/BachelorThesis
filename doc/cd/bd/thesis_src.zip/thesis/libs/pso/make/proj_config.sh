#!/bin/bash

######################################################################
#---------------------- PROJECT CONFIGURATIONS ----------------------#
######################################################################

# Full name of the project
PROJ_NAME=ParticleSwarmOptimization

# Code name of the project
PROJ_CODE_NAME=pso