#!/bin/bash

######################################################################
#---------------------- PROJECT CONFIGURATIONS ----------------------#
######################################################################

# Full name of the project
PROJ_NAME=ParallelComputing

# Code name of the project
PROJ_CODE_NAME=parallel