//
// Created by jakub on 1/26/16.
//

#ifndef BACHELOR_THESIS_FITNESS_FMEASURE_DISTINCT_H
#define BACHELOR_THESIS_FITNESS_FMEASURE_DISTINCT_H

#include <language/language.h>
#include <pso/fitness_updater.h>

using namespace pso;

class FitnessFmeasureDistinct : public FitnessUpdater {
private:
    //-----------------------------------------------------------//
    //  PRIVATE FIELDS
    //-----------------------------------------------------------//

    std::vector<Language*>* nativeLanguages;
    std::vector<Language*>* foreignLanguages;

protected:
    //-----------------------------------------------------------//
    //  PROTECTED METHODS
    //-----------------------------------------------------------//

    virtual double fitnessValue(const Particle& p) override;

public:
    //-----------------------------------------------------------//
    //  CONSTRUCTORS
    //-----------------------------------------------------------//

    FitnessFmeasureDistinct(ParticleShPtr_ConstVectorShPtr particles,
                            const ParticleDecoder* particleDecoder,
                            std::vector<Language*>* nativeLanguages,
                            std::vector<Language*>* foreignLanguages);

    ~FitnessFmeasureDistinct();

    //-----------------------------------------------------------//
    //  PUBLIC METHODS
    //-----------------------------------------------------------//
};


#endif //BACHELOR_THESIS_FITNESS_FMEASURE_DISTINCT_H
