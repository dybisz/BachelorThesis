#!/bin/bash

# shared / static
LIB_TYPE=shared

# Standard for shared is: .so
# Standard for static is: .a
LIB_EXTENSION=.so

# Convention
LIB_PREFIX=lib

