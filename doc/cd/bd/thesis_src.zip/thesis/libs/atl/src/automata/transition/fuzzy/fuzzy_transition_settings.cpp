//
// Created by jakub on 12/3/15.
//

#include <automata/transition/fuzzy/fuzzy_transition_settings.h>

namespace transition_settings
{
    float FUZZY_MIN = 0.0f;
    float FUZZY_MAX = 1.0f;
}