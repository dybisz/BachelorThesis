//
// I do not suppose this header will last long ...
// Created by dybisz on 11/11/15.
//

#ifndef AC_COLOR_TEXT_H
#define AC_COLOR_TEXT_H

#define RED_BOLD_TEXT(text)         "\033[1;31m" text "\033[0m"
#define RED_TEXT(text)              "\033[0;31m" text "\033[0m"

#define BLUE_BOLD_TEXT(text)        "\033[1;34m" text "\033[0m"
#define BLUE_TEXT(text)             "\033[0;34m" text "\033[0m"

#define GREEN_BOLD_TEXT(text)       "\033[1;32m" text "\033[0m"
#define GREEN_TEXT(text)            "\033[0;32m" text "\033[0m"

#endif //AC_COLOR_TEXT_H
