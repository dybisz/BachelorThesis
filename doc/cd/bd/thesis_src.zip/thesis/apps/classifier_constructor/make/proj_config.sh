#!/bin/bash

######################################################################
#---------------------- PROJECT CONFIGURATIONS ----------------------#
######################################################################

# Full name of the project
PROJ_NAME=ClassifierConstructor

# Code name of the project
PROJ_CODE_NAME=cc