//
// Created by jakub on 1/19/16.
//

#ifndef BACHELOR_THESIS_SETTINGS_H
#define BACHELOR_THESIS_SETTINGS_H

#include <string>

namespace settings{
    extern std::string LOGS_SETTINGS_FILE_NAME;

    void setAllFlags();

    void printAllSettings();
}

#endif //BACHELOR_THESIS_SETTINGS_H
