//
// Created by jakub on 1/19/16.
//

#ifndef BACHELOR_THESIS_APP_SETTINGS_H
#define BACHELOR_THESIS_APP_SETTINGS_H

namespace settings {

    extern int EXPERIMENT_ID;

    void setAppFlags();

    /*
     * Prints all the settings.
     */
    void printAppSettings();
}

#endif //BACHELOR_THESIS_APP_SETTINGS_H
